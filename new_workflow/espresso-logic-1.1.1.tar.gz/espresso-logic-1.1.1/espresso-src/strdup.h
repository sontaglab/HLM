#ifndef __H_STRDUP
#define __H_STRDUP

#ifndef strdup
char * strdup(const char *str);
#endif

#endif
